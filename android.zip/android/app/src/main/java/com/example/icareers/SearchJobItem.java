package com.example.icareers;

public class SearchJobItem {

    private String jobId;
    private String jobTitle;
    private  String company;
    private String location;
    private String specialization;
    private String postDate;
    private String min_salary;
    private String max_salary;

    // Constructor
    public SearchJobItem(String jobId,String jobTitle,String company,String location, String specialization, String postDate, String min_salary,String max_salary) {
        this.jobId = jobId;
        this.jobTitle = jobTitle;
        this.specialization = specialization;
        this.postDate = postDate;
        this.company=company;
        this.location=location;
        this.min_salary=min_salary;
        this.max_salary=max_salary;
    }

    public  String getJobId(){return  this.jobId;}
    public  void setJobId(String jobId){this.jobId=jobId;}

    public  String getCompany(){return  this.company;}
    public  void setCompany(String company){this.company=company;}

    public  String getLocation(){return  this.location;}
    public  void setLocation(String location){this.location=location;}

    public  String getMin_salary(){return  this.min_salary;}
    public  void setMin_salary(String min_salary){this.min_salary=min_salary;}
    public  String getMax_salary(){return  this.max_salary;}
    public  void setMax_salary(String max_salary){this.max_salary=max_salary;}
    public String getJobTitle() {
        return this.jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getSpecialization() {
        return this.specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getPostDate() {
        return this.postDate;
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

}
