package com.example.icareers;

import java.io.Serializable;

public class JobApplication implements Serializable {
    private int applicationId;
    private String applicantName;
    private String applicantMail;
    private String status;
    private String applicationDate;

    public JobApplication(int applicationId,String applicantName,String applicationDate,String email, String status) {
        this.applicationId = applicationId;
        this.applicantName = applicantName;
        this.applicantMail = email;
        this.applicationDate = applicationDate;
        this.status = status;
    }

    public JobApplication(int applicationId,String applicantName,String applicationDate, String status) {
        this.applicationId = applicationId;
        this.applicantName = applicantName;
        this.applicantMail = "";
        this.applicationDate = applicationDate;
        this.status = status;
    }

    public int getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(int id) {
        this.applicationId = id;
    }



    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public  String getApplicantMail(){
        return  this.applicantMail;
    }

    public  void setApplicantMail(String mail){
        this.applicantMail = mail;
    }

    public  String getApplicationDate(){
        return this.applicationDate;
    }
    public  void setApplicationDate(String applicationDate){
        this.applicationDate = applicationDate;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
