package com.example.icareers;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


public class MainActivity extends AppCompatActivity {
    public static final String link = "http://10.0.0.18:8000/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        isUserLoggedIn();
    }
    private void isUserLoggedIn() {
        SharedPreferences sharedPreferences = getSharedPreferences("loginPref", MODE_PRIVATE);
        String userType = sharedPreferences.getString("type", "");

        if (userType.equals("user")) {
            Intent searchJobIntent = new Intent(MainActivity.this, ViewJobsActivity.class);
            startActivity(searchJobIntent);
        } else if (userType.equals("company")) {
            Intent postedJobsIntent = new Intent(MainActivity.this, PostedJobsActivity.class);
            startActivity(postedJobsIntent);
        }else{
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }
}