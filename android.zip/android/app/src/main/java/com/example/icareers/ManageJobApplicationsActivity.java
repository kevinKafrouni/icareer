package com.example.icareers;

import static com.example.icareers.MainActivity.link;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.*;

public class ManageJobApplicationsActivity extends AppCompatActivity {
    private static final String jobapplications_URL =   link + "jobapplications";
    private List<JobApplication> jobApplicationsList = new ArrayList<JobApplication>();

    private RecyclerView recyclerView;
    private JobApplicationAdapter adapt;

    private TextView jobtest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_job_applications);

        // Receive the job ID passed from the previous activity
        String jobId = getIntent().getStringExtra("jobId");
        jobtest = findViewById(R.id.jobTest);
        jobtest.setText("testing job id is  : "+jobId);

        recyclerView = findViewById(R.id.applicationsRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapt = new JobApplicationAdapter(this,jobApplicationsList);
        recyclerView.setAdapter(adapt);

        getJobApplications(jobId);

    }

    private void getJobApplications(String jobId) {

        String jobApplicationsUrl = jobapplications_URL + "?jobid=" + jobId;

        StringRequest request = new StringRequest(Request.Method.GET, jobApplicationsUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            jobApplicationsList.clear();

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                // Parse data from JSON response
                                int applicationId = jsonObject.getInt("application_id");
                                String applicantName = jsonObject.getString("first_name")+" "+jsonObject.getString("last_name");
                                String applicantEmail = jsonObject.getString("email");
                                String applicationDay = jsonObject.getString("application_day");
                                String status_id = jsonObject.getString("app_status_id");
                                String status = jsonObject.getString("status");


                                // Create a JobApplication object
                                JobApplication jobApplication = new JobApplication(applicationId,applicantName,applicationDay,applicantEmail,status);
                                jobApplicationsList.add(jobApplication);

                            }
                            JobApplication test = jobApplicationsList.get(0);
                            Log.d("added job","response : "+test.getApplicationId()+" ,"+test.getApplicantName()+" "+test.getApplicationDate()+" "+test.getApplicantMail()+" "+test.getStatus());

                            adapt.notifyDataSetChanged();
                            Log.d("AdapterRefresh", "Adapter notified of dataset changes");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle error
                        Toast.makeText(ManageJobApplicationsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(request);
    }
    public void goBackToPostedJobs(View v){
        Intent intent = new Intent(this, PostedJobsActivity.class);
        startActivity(intent);
    }
}
