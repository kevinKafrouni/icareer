package com.example.icareers;

import static com.example.icareers.MainActivity.link;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ViewJobsActivity extends AppCompatActivity {

    private static final String viewjobs_URL = link +"getJobs";
    private RequestQueue requestQueue;
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_for_jobs);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        BottomMenuHelper.setupBottomNavigation(bottomNavigationView, this);

        requestQueue = Volley.newRequestQueue(getApplicationContext());


        List<SearchJobItem> jobItemList = new ArrayList<>();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        SearchJobAdapter jobAdapter = new SearchJobAdapter(jobItemList);
        recyclerView.setAdapter(jobAdapter);
        getAllJobs();

    }
    private void getAllJobs() {
        StringRequest req = new StringRequest(Request.Method.GET, viewjobs_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            List<SearchJobItem> jobItemList = new ArrayList<>();


                            for (int i = 0; i < array.length(); i++) {

                                JSONObject obj = array.getJSONObject(i);
                                Log.d("API_RESPONSE2", "Response: "+obj);
                                String jobId = obj.getString("job_id");
                                String jobTitle = obj.getString("job_title");
                                String company = obj.getString("company_name");
                                String location = obj.getString("location_name");
                                String min_salary = obj.getString("min_salary");
                                String max_salary = obj.getString("max_salary");
                                String postDate = obj.getString("posted_date");
                                String specName = obj.getString("spec_name");

                                SearchJobItem jobItem = new SearchJobItem(jobId,jobTitle, company,location,specName, postDate,min_salary,max_salary);
                                jobItemList.add(jobItem);
                            }

                            SearchJobAdapter adapter = (SearchJobAdapter) recyclerView.getAdapter();
                            adapter.setJobItems(jobItemList);
                            adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ViewJobsActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        // Add the request to the RequestQueue
        requestQueue.add(req);
    }
}
