package com.example.icareers;

import static com.example.icareers.MainActivity.link;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ViewApplicationsActivity extends AppCompatActivity {
    private static final String userjobapplications_URL =   link + "androiduserapplications";
    private List<JobApplication> jobApplicationsList = new ArrayList<JobApplication>();

    private RecyclerView recyclerView;
    private JobApplicationAdapter adapt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_applications);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        BottomMenuHelper.setupBottomNavigation(bottomNavigationView, this);

        SharedPreferences sharedPreferences = getSharedPreferences("loginPref", MODE_PRIVATE);
        String userId = sharedPreferences.getString("user_id", "");


        jobApplicationsList.add(new JobApplication(1, "company1 ", "01-01-2023", "Pending"));
        jobApplicationsList.add(new JobApplication(2, "company1", "2023-01-16", "Accepted"));
        jobApplicationsList.add(new JobApplication(3, "company1", "2023-01-17", "Rejected"));



        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapt = new JobApplicationAdapter(this,jobApplicationsList);
        recyclerView.setAdapter(adapt);

        getJobApplications(userId);
    }
    private void getJobApplications(String userId) {

        String jobApplicationsUrl = userjobapplications_URL + "?userId=" + userId;

        StringRequest request = new StringRequest(Request.Method.GET, jobApplicationsUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            jobApplicationsList.clear();

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                int applicationId = jsonObject.getInt("application_id");
                                String applicantName = jsonObject.getString("job_title");
                                String applicationDay = jsonObject.getString("application_day");
                                String status = jsonObject.getString("status");

                                JobApplication jobApplication = new JobApplication(applicationId,applicantName,applicationDay,status);
                                jobApplicationsList.add(jobApplication);
                            }
                            adapt.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ViewApplicationsActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        Volley.newRequestQueue(this).add(request);
    }
}
