package com.example.icareers;

import android.content.Context;
import android.view.*;
import android.widget.TextView;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class JobApplicationAdapter extends RecyclerView.Adapter<JobApplicationAdapter.ViewHolder> {

    private List<JobApplication> originalApplications;
    private Context context;
    public JobApplicationAdapter(Context context, List<JobApplication> applications) {
        originalApplications = applications;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.job_application_list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        JobApplication application = originalApplications.get(position);
        holder.bind(application);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle click event here, you can start a new activity or show a dialog with job application details
                showJobApplicationDetails(application);
            }
        });
    }

    private void showJobApplicationDetails(JobApplication application) {
        // Create an Intent to open a new activity and pass the selected job application details
        Intent intent = new Intent(this.context, JobApplicationDetailActivity.class);
        intent.putExtra("jobApplication", application);
        context.startActivity(intent);
    }


    @Override
    public int getItemCount() {
        return originalApplications.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView applicantNameTextView;
        private final TextView applicantMailTextView;
        private final TextView applicationDateTextView;
        private final TextView statusTextView;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            applicantNameTextView = itemView.findViewById(R.id.applicantName);
            applicationDateTextView = itemView.findViewById(R.id.applicationDate);
            applicantMailTextView = itemView.findViewById(R.id.applicantEmail);
            statusTextView = itemView.findViewById(R.id.applicationStatus);
        }

        void bind(JobApplication application) {
            applicantNameTextView.setText(application.getApplicantName());
            applicantMailTextView.setText(application.getApplicantMail());
            applicationDateTextView.setText(application.getApplicationDate());
            statusTextView.setText(application.getStatus());
        }
    }
}
