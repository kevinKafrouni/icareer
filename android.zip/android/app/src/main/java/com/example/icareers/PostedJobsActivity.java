package com.example.icareers;


import static com.example.icareers.MainActivity.link;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class PostedJobsActivity extends AppCompatActivity {
    private static final String postedJobs_URL = link +"androidjobsposted";
    private RequestQueue requestQueue;
    private RecyclerView recyclerView;

    private Button viewApplicationsButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_posted_jobs);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        BottomMenuHelper.setupBottomNavigation(bottomNavigationView, this);
        if (bottomNavigationView.getSelectedItemId() != R.id.navigation_posted_jobs) {
            bottomNavigationView.setSelectedItemId(R.id.navigation_posted_jobs);
        }
        requestQueue = Volley.newRequestQueue(getApplicationContext());


        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<JobItem> jobItemList = new ArrayList<>();
        JobAdapter jobAdapter = new JobAdapter(jobItemList);
        recyclerView.setAdapter(jobAdapter);

        getPostedJobs();



    }
    private void getPostedJobs() {
        StringRequest req = new StringRequest(Request.Method.GET, postedJobs_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            List<JobItem> jobItemList = new ArrayList<>();

                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                String jobId = obj.getString("job_id");
                                String jobTitle = obj.getString("job_title");
                                String postDate = obj.getString("post_date");
                                String closeDate = obj.getString("close_date");
                                String specName = obj.getString("spec_name");

                                JobItem jobItem = new JobItem(jobId,jobTitle, specName, postDate, closeDate);
                                jobItemList.add(jobItem);
                            }

                            // Update RecyclerView with fetched job items
                            JobAdapter adapter = (JobAdapter) recyclerView.getAdapter();
                            adapter.setJobItems(jobItemList);
                            adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(PostedJobsActivity.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        // Add the request to the RequestQueue
        requestQueue.add(req);
    }

}

