package com.example.icareers;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.*;
public class SearchJobAdapter extends RecyclerView.Adapter<SearchJobAdapter.SearchJobViewHolder> {
    private List<SearchJobItem> jobList;
    public SearchJobAdapter(List<SearchJobItem> jobList) {
        this.jobList = jobList;
    }
    public void setJobItems(List<SearchJobItem> jobList) {
        if (this.jobList != null) {
            this.jobList.clear();
            this.jobList.addAll(jobList);
        } else {
            this.jobList = new ArrayList<>(jobList);
        }
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public SearchJobAdapter.SearchJobViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.search_job_item, parent, false);
        return new SearchJobAdapter.SearchJobViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull SearchJobAdapter.SearchJobViewHolder holder, int position) {
        SearchJobItem jobItem = jobList.get(position);
        holder.postedDate.setText(jobItem.getPostDate());
        holder.title.setText(jobItem.getJobTitle());
        holder.spec.setText(jobItem.getSpecialization());
        holder.company.setText(jobItem.getCompany());
        holder.location.setText(jobItem.getLocation());
        holder.min_salary.setText(jobItem.getMin_salary());
        holder.max_salary.setText(jobItem.getMax_salary());
        holder.applybtn.setOnClickListener(v -> {
            String jobId = jobItem.getJobId();
        });
    }
    @Override
    public int getItemCount() {
        return jobList.size();
    }
    static class SearchJobViewHolder extends RecyclerView.ViewHolder {
        TextView postedDate;
        TextView title;
        TextView spec;
        TextView company;
        TextView location;
        TextView min_salary;
        TextView max_salary;
        Button applybtn;
        public SearchJobViewHolder(@NonNull View itemView) {
            super(itemView);
            postedDate = itemView.findViewById(R.id.posteddate);
            title = itemView.findViewById(R.id.jobtitle);
            spec = itemView.findViewById(R.id.specialization);
            company = itemView.findViewById(R.id.companyname);
            location = itemView.findViewById(R.id.location);
            min_salary = itemView.findViewById(R.id.min_salary);
            max_salary = itemView.findViewById(R.id.max_salary);
            applybtn = itemView.findViewById(R.id.applybtn);
        }
    }
}