package com.example.icareers;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class JobApplicationDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.job_application_details);

        JobApplication jobApplication = getIntent().getParcelableExtra("jobApplication");

        // Initialize views and set job application details
        TextView applicantNameDetail = findViewById(R.id.applicantNameDetail);
        TextView applicantEmailDetail = findViewById(R.id.applicantEmailDetail);
        TextView applicantDetails = findViewById(R.id.applicantDetails);
        // Set job application details to the views
        applicantNameDetail.setText(jobApplication.getApplicantName());
        applicantEmailDetail.setText(jobApplication.getApplicantMail());
        // Set other details accordingly
        // ...
    }
}
