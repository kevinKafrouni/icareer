package com.example.icareers;

import static com.example.icareers.MainActivity.link;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {
    private EditText emailEditText, passwordEditText;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.pass);
        requestQueue = Volley.newRequestQueue(this);
    }

    public void onLoginClick(View view) {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if(TextUtils.isEmpty(email)){
            emailEditText.setError("Enter your email");
            return;
        }
        if(TextUtils.isEmpty(password)){
            passwordEditText.setError("enter the password");
        }
        loginUser(email, password);
    }

    private void loginUser(String email, String password) {
        String url = link + "login";

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("email", email);
            jsonObject.put("password", password);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            // Handle the response here
                            if (response.getString("type").equals("user")) {
                                try {
                                    JSONArray userDataArray = response.getJSONArray("data");
                                    // Handle user data array
                                    JSONObject userData = userDataArray.getJSONObject(0); // Get the first object from the array

                                    SharedPreferences sharedPreferences = getSharedPreferences("loginPref", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("type", "user");
                                    editor.putString("user_id", userData.getString("user_id"));
                                    editor.apply();

                                    Intent intent = new Intent(LoginActivity.this, PostedJobsActivity.class);
                                    startActivity(intent);

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }else if (response.getString("type").equals("company")) {
                                    JSONArray companyDataArray = response.getJSONArray("companydata");
                                    JSONObject companyData = companyDataArray.getJSONObject(0); // Get the first object from the array

                                // Saving user's email to SharedPreferences
                                SharedPreferences sharedPreferences = getSharedPreferences("loginPref", MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString("type", "company");
                                editor.putString("company_id", companyData.getString("company_id"));
                                editor.apply();

                                // Handle company data
                                    Log.d("company logged", " data:" + companyData);
                                    Intent intent = new Intent(LoginActivity.this, PostedJobsActivity.class);
                                    startActivity(intent);
                                }

                            } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors here
                        Log.d("Login Error", error.toString());
                        Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(jsonObjectRequest);
    }
}
