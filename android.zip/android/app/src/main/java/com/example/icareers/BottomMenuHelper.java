package com.example.icareers;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationItemView;
import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BottomMenuHelper {

    public static void setupBottomNavigation(BottomNavigationView bottomNavigationView, Activity activity) {
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.navigation_add_job:
                    activity.startActivity(new Intent(activity, PostJobActivity.class));
                    return true;
                case R.id.navigation_posted_jobs:
                    activity.startActivity(new Intent(activity, PostedJobsActivity.class));
                    return true;
                case R.id.navigation_company_profile:
                    activity.startActivity(new Intent(activity, ProfileActivity.class));
                    return true;
                case R.id.navigation_find_job:
                    activity.startActivity(new Intent(activity, ViewJobsActivity.class));
                    return true;
                case R.id.navigation_applications:
                    activity.startActivity(new Intent(activity, ViewApplicationsActivity.class));
                    return true;
                case R.id.navigation_user_profile:
                    activity.startActivity(new Intent(activity, UserProfileActivity.class));
                    return true;
            }
            return false;
        });

    }
}

