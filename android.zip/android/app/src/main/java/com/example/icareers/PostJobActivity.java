package com.example.icareers;


import static com.example.icareers.MainActivity.link;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class PostJobActivity extends AppCompatActivity {
    public RequestQueue requestQueue;
    private static String jobTypes_URL = link + "jobtypes";
    private static String specs_URL =  link + "getallspecs";

    private String selectedJobType = "1";
    private String selectedSpec = "1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_job);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        BottomMenuHelper.setupBottomNavigation(bottomNavigationView, this);


        requestQueue = Volley.newRequestQueue(getApplicationContext());
        getJobTypes();
        getSpecs();
    }

    public void goBack(View v){
        Intent intent = new Intent(PostJobActivity.this, PostedJobsActivity.class);
        startActivity(intent);
    }
    private void getJobTypes() {
        StringRequest req = new StringRequest(Request.Method.GET, jobTypes_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            List<String> jobTypeNames = new ArrayList<>();
                            final List<String> jobTypeIds = new ArrayList<>();

                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                String id = obj.getString("value");
                                String name = obj.getString("label");

                                // Add job type names and IDs to respective lists
                                jobTypeNames.add(name);
                                jobTypeIds.add(id);
                            }

                            // Create ArrayAdapter using jobTypeNames
                            ArrayAdapter<String> adapter = new ArrayAdapter<>(PostJobActivity.this,
                                    android.R.layout.simple_spinner_item, jobTypeNames);
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                            Spinner spinner = findViewById(R.id.jobtypes);
                            spinner.setAdapter(adapter);

                            // Handle Spinner item selection if needed
                            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                    String selectedJobTypeId = jobTypeIds.get(position);
                                    String selectedJobTypeName = jobTypeNames.get(position);
                                    // Handle selected item
                                    selectedJobType =  selectedJobTypeId ;
                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {
                                    // Handle no selection
                                }
                            });

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(PostJobActivity.this,error.toString(),Toast.LENGTH_LONG).show();
            }
        });




        // Add the request to the RequestQueue (assuming you have a RequestQueue instance)
        requestQueue.add(req);
    }


    private void getSpecs() {
        StringRequest req = new StringRequest(Request.Method.GET, specs_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            List<String> specNames = new ArrayList<>();
                            final List<String> specIds = new ArrayList<>();

                            for (int i = 0; i < array.length(); i++) {
                                JSONObject obj = array.getJSONObject(i);
                                String id = obj.getString("value");
                                String name = obj.getString("label");

                                // Add job type names and IDs to respective lists
                                specNames.add(name);
                                specIds.add(id);
                            }

                            // Create ArrayAdapter using jobTypeNames
                                ArrayAdapter<String> adapter = new ArrayAdapter<>(PostJobActivity.this,
                                    android.R.layout.simple_spinner_item, specNames);
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                            AutoCompleteTextView auto = findViewById(R.id.specs);
                            auto.setAdapter(adapter);

                            auto.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    String selectedSpecId = specIds.get(position);
                                    String selectedSpecName = specNames.get(position);
                                    // Handle selected item
                                    selectedSpec = selectedSpecId;
                                }
                            });
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(PostJobActivity.this,error.toString(),Toast.LENGTH_LONG).show();
            }
        });

        requestQueue.add(req);
    }

    public void postJob(View v) {
        Button postButton = findViewById(R.id.postjobbtn); // Replace postButton with your actual button ID
        postButton.setEnabled(false);

        EditText title = findViewById(R.id.title);
        AutoCompleteTextView spec = findViewById(R.id.specs);
        EditText min = findViewById(R.id.min);
        EditText max = findViewById(R.id.max);
        EditText desc = findViewById(R.id.desc);
        Spinner sp = findViewById(R.id.jobtypes);

        String job_title = title.getText().toString();
        String min_salary = min.getText().toString();
        String max_salary = max.getText().toString();
        String job_description = desc.getText().toString();

        String url=link + "androidpostjob";


        StringRequest req = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("result:",response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        postButton.setEnabled(true);
                        Log.d("volleyerror", ""+error);
                        Intent intent = new Intent(PostJobActivity.this, PostedJobsActivity.class);
                        startActivity(intent);
                    }
                }
        ){
            protected HashMap<String,String> getParams() throws AuthFailureError{
                HashMap<String,String> map = new HashMap<>();

                map.put("job_title",job_title);
                map.put("spec_id",selectedSpec);
                map.put("min_salary",min_salary);
                map.put("max_salary",max_salary);
                map.put("job_description",job_description);
                map.put("job_type_id",selectedJobType);
                return map;
            }
        };
        requestQueue.add(req);
    }
}

