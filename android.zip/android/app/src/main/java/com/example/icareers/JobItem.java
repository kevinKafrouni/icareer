package com.example.icareers;

public class JobItem {

    private String jobId;
    private String jobTitle;
    private String specialization;
    private String postDate;
    private String closeDate;

    // Constructor
    public JobItem(String jobId,String jobTitle, String specialization, String postDate, String closeDate) {
        this.jobId = jobId;
        this.jobTitle = jobTitle;
        this.specialization = specialization;
        this.postDate = postDate;
        this.closeDate = closeDate;
    }

    public  String getJobId(){return  this.jobId;}
    public  void setJobId(String jobId){this.jobId=jobId;}
    public String getJobTitle() {
        return this.jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getSpecialization() {
        return this.specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getPostDate() {
        return this.postDate;
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getCloseDate() {
        return this.closeDate;
    }

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    }
}

