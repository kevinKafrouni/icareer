<?php
define('HOST','localhost');
define('USER','kevin');
define('PASSWORD','k1772002k');
define('DATABASE','icareer');

$con = mysqli_connect(HOST,USER,PASSWORD,DATABASE);

$q = "SELECT * FROM job_type";
$result = mysqli_query($con, $q);
$jobTypes = array();
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $jobTypes[$row['job_type_id']] = $row['job_type_name'];
    }
} else {
    echo "Error executing the query: " . mysqli_error($con);
}

mysqli_close($con);
echo json_encode($jobTypes);
?>